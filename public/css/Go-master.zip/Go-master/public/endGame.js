function div_show(){
    document.getElementById('pop').style.display = "block";
}

function div_hide(){
    document.getElementById('pop').style.display = "none";
}

function playAgain(){
    window.location = 'menu.html';
}

function openLeader(){
    window.location = 'leaderboard.html';
}